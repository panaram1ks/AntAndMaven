
public class Test {

public static void main(String[] args) {
	
	HelloWorld hw = new HelloWorld();
	
    hw.dispalyMessage();
}

}
public class HelloWorld {

void dispalyMessage() {
	
    System.out.println("Hello World!");
}

}